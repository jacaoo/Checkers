import tds.model.*
import tds.ui.*

fun main(){
    ConsoleApplication.start()
}


